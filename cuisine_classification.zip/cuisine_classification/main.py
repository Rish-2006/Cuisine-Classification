"""
main.py
-------
Single orchestration script that runs the full end-to-end pipeline:

  1. Data Preprocessing  (clean → encode → save)
  2. Model Training      (Logistic Regression + Random Forest)
  3. Model Evaluation    (metrics, confusion matrices, reports)

Usage
-----
  python main.py                  # full pipeline, CV enabled
  python main.py --no-cv          # skip cross-validation (faster)
  python main.py --data PATH      # custom raw CSV path
  python main.py --help

All outputs
-----------
  data/processed.csv
  models/preprocessor.pkl
  models/logistic_regression.pkl
  models/random_forest.pkl
  models/split_indices.pkl
  models/feature_columns.pkl
  reports/confusion_matrix_lr.png
  reports/confusion_matrix_rf.png
  reports/per_cuisine_f1_lr.png
  reports/per_cuisine_f1_rf.png
  reports/feature_importance_rf.png
  reports/bias_analysis.png
  reports/classification_report_logistic_regression.txt
  reports/classification_report_random_forest.txt
  reports/evaluation_summary.txt
"""

from __future__ import annotations

import argparse
import logging
import os
import sys
import time

import joblib

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from src.data_preprocessing import DataPreprocessor
from src.train import (
    MODELS_DIR,
    PROCESSED_DATA_PATH,
    stratified_split,
    train_and_save,
)
from src.evaluate import main as run_evaluation

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  [%(levelname)s]  %(message)s",
    datefmt="%H:%M:%S",
)
logger = logging.getLogger(__name__)

BASE_DIR              = os.path.dirname(os.path.abspath(__file__))
DEFAULT_RAW_DATA      = os.path.join(BASE_DIR, "data", "dataset.csv")
PREPROCESSOR_SAVE_PATH = os.path.join(MODELS_DIR, "preprocessor.pkl")

BANNER = r"""
╔══════════════════════════════════════════════════════════════╗
║         CUISINE CLASSIFICATION PIPELINE  — Task 3           ║
║         Logistic Regression  vs  Random Forest               ║
╚══════════════════════════════════════════════════════════════╝
"""


def step_preprocess(raw_data_path: str) -> tuple:
    logger.info("┌─ STEP 1: DATA PREPROCESSING")
    t0 = time.time()
    preprocessor = DataPreprocessor()
    X, y, feature_columns = preprocessor.fit_transform(raw_data_path)
    preprocessor.save_processed(PROCESSED_DATA_PATH)
    os.makedirs(MODELS_DIR, exist_ok=True)
    joblib.dump(preprocessor, PREPROCESSOR_SAVE_PATH)
    logger.info("Preprocessor saved → %s", PREPROCESSOR_SAVE_PATH)
    logger.info("└─ Step 1 done in %.1fs\n", time.time() - t0)
    return X, y, feature_columns, preprocessor


def step_train(X, y, feature_columns: list[str], run_cv: bool) -> dict:
    logger.info("┌─ STEP 2: MODEL TRAINING  (cv=%s)", run_cv)
    t0 = time.time()
    X_train, X_test, y_train, y_test = stratified_split(X, y)
    models = train_and_save(
        X_train, y_train, X_test, y_test, feature_columns, run_cv=run_cv,
    )
    logger.info("└─ Step 2 done in %.1fs\n", time.time() - t0)
    return models


def step_evaluate() -> tuple:
    logger.info("┌─ STEP 3: EVALUATION & REPORTING")
    t0 = time.time()
    results_lr, results_rf = run_evaluation()
    logger.info("└─ Step 3 done in %.1fs\n", time.time() - t0)
    return results_lr, results_rf


def print_final_summary(results_lr: dict, results_rf: dict) -> None:
    print("\n" + "=" * 60)
    print("  FINAL RESULTS SUMMARY")
    print("=" * 60)
    print(f"  {'Metric':<22} {'LR':>12} {'Random Forest':>14}")
    print("-" * 60)
    for key, label in [
        ("accuracy",        "Accuracy"),
        ("macro_f1",        "Macro F1"),
        ("weighted_f1",     "Weighted F1"),
        ("macro_precision", "Macro Precision"),
        ("macro_recall",    "Macro Recall"),
    ]:
        lr_val = results_lr[key]
        rf_val = results_rf[key]
        flag   = " ✓" if rf_val >= lr_val else ""
        print(f"  {label:<22} {lr_val:>12.4f} {rf_val:>14.4f}{flag}")
    print("=" * 60)
    print("\n  Reports → reports/")
    print("  Models  → models/\n")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Cuisine Classification Pipeline")
    parser.add_argument("--data",  default=DEFAULT_RAW_DATA,
                        help=f"Path to raw CSV (default: {DEFAULT_RAW_DATA})")
    parser.add_argument("--no-cv", action="store_true", default=False,
                        help="Skip cross-validation (faster)")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    print(BANNER)
    total_start = time.time()

    if not os.path.exists(args.data):
        logger.error("Raw data file not found: %s", args.data)
        sys.exit(1)

    X, y, feature_columns, preprocessor = step_preprocess(args.data)
    models = step_train(X, y, feature_columns, run_cv=not args.no_cv)
    results_lr, results_rf = step_evaluate()
    print_final_summary(results_lr, results_rf)
    logger.info("Pipeline finished in %.1fs", time.time() - total_start)


if __name__ == "__main__":
    main()
