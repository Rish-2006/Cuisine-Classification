"""
src/evaluate.py
---------------
Load trained models and test-split data, compute evaluation metrics,
generate confusion-matrix heatmaps, per-cuisine breakdown charts, a
feature-importance plot (RF), and write a plain-text summary report.

Outputs  (written to  reports/)
--------------------------------
  reports/classification_report_logistic_regression.txt
  reports/classification_report_random_forest.txt
  reports/confusion_matrix_lr.png
  reports/confusion_matrix_rf.png
  reports/per_cuisine_f1_lr.png
  reports/per_cuisine_f1_rf.png
  reports/feature_importance_rf.png
  reports/bias_analysis.png
  reports/evaluation_summary.txt

Run as a script
---------------
  python src/evaluate.py
"""

from __future__ import annotations

import logging
import os
import warnings
from typing import Any

import joblib
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker
import numpy as np
import pandas as pd
import seaborn as sns
from sklearn.metrics import (
    accuracy_score,
    classification_report,
    confusion_matrix,
    f1_score,
    precision_score,
    recall_score,
)

warnings.filterwarnings("ignore")
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  [%(levelname)s]  %(message)s",
    datefmt="%H:%M:%S",
)
logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------
BASE_DIR      = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
MODELS_DIR    = os.path.join(BASE_DIR, "models")
REPORTS_DIR   = os.path.join(BASE_DIR, "reports")

MODEL_LR_PATH       = os.path.join(MODELS_DIR, "logistic_regression.pkl")
MODEL_RF_PATH       = os.path.join(MODELS_DIR, "random_forest.pkl")
SPLIT_PATH          = os.path.join(MODELS_DIR, "split_indices.pkl")
PREPROCESSOR_PATH   = os.path.join(MODELS_DIR, "preprocessor.pkl")

sns.set_theme(style="whitegrid", font_scale=0.9)


# ---------------------------------------------------------------------------
# Loaders
# ---------------------------------------------------------------------------

def load_artifacts() -> tuple[Any, Any, dict, list[str]]:
    logger.info("Loading model artifacts …")
    lr_model     = joblib.load(MODEL_LR_PATH)
    rf_model     = joblib.load(MODEL_RF_PATH)
    split        = joblib.load(SPLIT_PATH)
    preprocessor = joblib.load(PREPROCESSOR_PATH)
    class_names  = preprocessor.get_class_names()
    logger.info("Loaded LR, RF, split data, and %d class names.", len(class_names))
    return lr_model, rf_model, split, class_names


# ---------------------------------------------------------------------------
# Core metric computation
# ---------------------------------------------------------------------------

def compute_metrics(
    model: Any,
    X_test: pd.DataFrame,
    y_test: np.ndarray,
    class_names: list[str],
    model_name: str,
) -> dict[str, Any]:
    y_pred = model.predict(X_test)

    acc        = accuracy_score(y_test, y_pred)
    macro_p    = precision_score(y_test, y_pred, average="macro",    zero_division=0)
    macro_r    = recall_score   (y_test, y_pred, average="macro",    zero_division=0)
    macro_f1   = f1_score       (y_test, y_pred, average="macro",    zero_division=0)
    weighted_f1 = f1_score      (y_test, y_pred, average="weighted", zero_division=0)
    report_str  = classification_report(y_test, y_pred, target_names=class_names, zero_division=0)
    per_class_f1 = f1_score(y_test, y_pred, average=None, zero_division=0)
    cm           = confusion_matrix(y_test, y_pred)

    logger.info(
        "[%s]  Acc=%.4f | Macro-P=%.4f | Macro-R=%.4f | "
        "Macro-F1=%.4f | Weighted-F1=%.4f",
        model_name, acc, macro_p, macro_r, macro_f1, weighted_f1,
    )

    return {
        "model_name":       model_name,
        "y_pred":           y_pred,
        "accuracy":         acc,
        "macro_precision":  macro_p,
        "macro_recall":     macro_r,
        "macro_f1":         macro_f1,
        "weighted_f1":      weighted_f1,
        "report_str":       report_str,
        "per_class_f1":     per_class_f1,
        "confusion_matrix": cm,
    }


# ---------------------------------------------------------------------------
# Plotting helpers
# ---------------------------------------------------------------------------

def _save_fig(fig: plt.Figure, path: str) -> None:
    os.makedirs(os.path.dirname(path), exist_ok=True)
    fig.savefig(path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    logger.info("Saved → %s", path)


def plot_confusion_matrix(
    cm: np.ndarray,
    class_names: list[str],
    model_name: str,
    out_path: str,
) -> None:
    """Row-normalised confusion matrix heatmap."""
    cm_norm = cm.astype(float) / cm.sum(axis=1, keepdims=True).clip(min=1)
    n = len(class_names)
    cell = max(0.45, 12 / n)
    fig, ax = plt.subplots(figsize=(n * cell + 2, n * cell + 1))
    sns.heatmap(
        cm_norm,
        annot=(n <= 20),
        fmt=".2f",
        cmap="Blues",
        xticklabels=class_names,
        yticklabels=class_names,
        linewidths=0.3,
        linecolor="lightgray",
        ax=ax,
        cbar_kws={"shrink": 0.7},
    )
    ax.set_xlabel("Predicted label", fontsize=11)
    ax.set_ylabel("True label",      fontsize=11)
    ax.set_title(f"Confusion Matrix — {model_name} (row-normalised)", fontsize=13, pad=12)
    plt.xticks(rotation=45, ha="right", fontsize=8)
    plt.yticks(rotation=0,  fontsize=8)
    _save_fig(fig, out_path)


def plot_per_cuisine_f1(
    per_class_f1: np.ndarray,
    class_names: list[str],
    model_name: str,
    out_path: str,
) -> None:
    """Horizontal bar chart — F1 score per cuisine, colour-coded by tier."""
    order        = np.argsort(per_class_f1)
    sorted_f1    = per_class_f1[order]
    sorted_names = [class_names[i] for i in order]
    colors = ["#d73027" if v < 0.20 else "#fee090" if v < 0.40 else "#1a9850"
              for v in sorted_f1]

    fig, ax = plt.subplots(figsize=(10, max(6, len(class_names) * 0.38)))
    bars = ax.barh(sorted_names, sorted_f1, color=colors, edgecolor="white", height=0.7)
    ax.bar_label(bars, fmt="%.2f", padding=3, fontsize=8)
    ax.axvline(0.20, color="red",   linestyle="--", linewidth=1, label="F1 = 0.20")
    ax.axvline(0.40, color="orange",linestyle="--", linewidth=1, label="F1 = 0.40")
    ax.set_xlim(0, 1.08)
    ax.set_xlabel("F1 Score", fontsize=11)
    ax.set_title(f"Per-Cuisine F1 Score — {model_name}", fontsize=13, pad=12)
    ax.legend(loc="lower right", fontsize=9)
    ax.xaxis.set_minor_locator(mticker.MultipleLocator(0.05))
    ax.grid(axis="x", which="minor", linestyle=":", linewidth=0.5, alpha=0.6)
    _save_fig(fig, out_path)


def plot_feature_importance(
    rf_model: Any,
    feature_columns: list[str],
    out_path: str,
    top_n: int = 20,
) -> None:
    """Top-N feature importances from the Random Forest."""
    importances = rf_model.feature_importances_
    idx = np.argsort(importances)[::-1][:top_n]
    top_names  = [feature_columns[i] for i in idx]
    top_values = importances[idx]

    fig, ax = plt.subplots(figsize=(10, 6))
    colors = plt.cm.viridis(np.linspace(0.2, 0.85, top_n))
    ax.barh(top_names[::-1], top_values[::-1], color=colors[::-1], edgecolor="white")
    ax.set_xlabel("Mean Decrease in Impurity", fontsize=11)
    ax.set_title(f"Top-{top_n} Feature Importances — Random Forest", fontsize=13, pad=12)
    ax.xaxis.set_minor_locator(mticker.AutoMinorLocator())
    ax.grid(axis="x", which="minor", linestyle=":", linewidth=0.5, alpha=0.6)
    _save_fig(fig, out_path)


def plot_bias_analysis(
    results_lr: dict,
    results_rf: dict,
    class_names: list[str],
    y_test: np.ndarray,
    out_path: str,
) -> None:
    """
    Scatter: test-set support (class size) vs F1 for each model.
    Reveals whether low F1 correlates with small support (data imbalance).
    """
    support = np.array([(y_test == i).sum() for i in range(len(class_names))])
    f1_lr   = results_lr["per_class_f1"]
    f1_rf   = results_rf["per_class_f1"]

    fig, axes = plt.subplots(1, 2, figsize=(14, 5), sharey=True)
    for ax, f1, title in zip(axes, [f1_lr, f1_rf], ["Logistic Regression", "Random Forest"]):
        sc = ax.scatter(support, f1, c=f1, cmap="RdYlGn", vmin=0, vmax=1,
                        s=80, edgecolors="gray", linewidths=0.4)
        for i, name in enumerate(class_names):
            ax.annotate(name, (support[i], f1[i]), fontsize=6.5, alpha=0.8,
                        xytext=(4, 2), textcoords="offset points")
        ax.set_xlabel("Test-set support (# samples)", fontsize=10)
        ax.set_ylabel("F1 Score", fontsize=10)
        ax.set_title(f"Bias Analysis — {title}", fontsize=11)
        ax.axhline(0.20, color="gray", linestyle="--", linewidth=0.8)
        fig.colorbar(sc, ax=ax, label="F1 Score")

    fig.suptitle(
        "Support vs F1 per Cuisine  (low support → low F1 indicates class imbalance)",
        fontsize=12, y=1.02,
    )
    _save_fig(fig, out_path)


# ---------------------------------------------------------------------------
# Text report
# ---------------------------------------------------------------------------

def write_summary_report(
    results_lr: dict,
    results_rf: dict,
    class_names: list[str],
    y_test: np.ndarray,
    out_dir: str,
) -> None:
    os.makedirs(out_dir, exist_ok=True)

    # Individual classification reports
    for res, tag in [(results_lr, "logistic_regression"), (results_rf, "random_forest")]:
        fpath = os.path.join(out_dir, f"classification_report_{tag}.txt")
        with open(fpath, "w") as f:
            f.write(f"Classification Report — {res['model_name']}\n")
            f.write("=" * 70 + "\n\n")
            f.write(res["report_str"])
        logger.info("Saved → %s", fpath)

    # Compute majority-class baseline for context
    from collections import Counter
    majority_class_idx = Counter(y_test).most_common(1)[0][0]
    majority_acc = float((y_test == majority_class_idx).mean())
    n_classes = len(class_names)

    lines = []
    lines.append("=" * 70)
    lines.append("CUISINE CLASSIFICATION — EVALUATION SUMMARY")
    lines.append("=" * 70)
    lines.append(f"  Dataset: Zomato Restaurant Dataset (Task 3)")
    lines.append(f"  Classes: {n_classes} cuisines  |  Test samples: {len(y_test)}")
    lines.append(f"  Majority-class baseline (always predict '{class_names[majority_class_idx]}'): {majority_acc:.4f}")
    lines.append(f"  Random-guess baseline (1/{n_classes}): {1/n_classes:.4f}")
    lines.append("")
    lines.append(f"{'Metric':<24} {'Logistic Regression':>22} {'Random Forest':>15}")
    lines.append("-" * 64)
    for key, label in [
        ("accuracy",           "Accuracy"),
        ("macro_precision",    "Macro Precision"),
        ("macro_recall",       "Macro Recall"),
        ("macro_f1",           "Macro F1"),
        ("weighted_f1",        "Weighted F1"),
    ]:
        lr_val  = results_lr[key]
        rf_val  = results_rf[key]
        winner  = " ← better" if rf_val >= lr_val else ""
        lines.append(f"  {label:<22} {lr_val:>22.4f} {rf_val:>15.4f}{winner}")

    lines.append("")
    lines.append("PER-CUISINE F1 SCORES")
    lines.append("-" * 64)
    lines.append(f"  {'Cuisine':<26} {'Support':>8} {'LR F1':>8} {'RF F1':>9} {'Note'}")
    lines.append("-" * 64)

    support = {name: int((y_test == i).sum()) for i, name in enumerate(class_names)}
    f1_lr   = dict(zip(class_names, results_lr["per_class_f1"]))
    f1_rf   = dict(zip(class_names, results_rf["per_class_f1"]))

    for name in sorted(class_names):
        sup   = support[name]
        lrf   = f1_lr.get(name, 0)
        rff   = f1_rf.get(name, 0)
        note  = " ⚠ RARE" if sup < 20 else (" ⚠ LOW F1" if max(lrf, rff) < 0.20 else "")
        lines.append(f"  {name:<26} {sup:>8} {lrf:>8.3f} {rff:>9.3f}{note}")

    lines.append("")
    lines.append("BIAS & CLASS IMBALANCE OBSERVATIONS")
    lines.append("-" * 64)
    low_support = [n for n, s in support.items() if s < 20]
    low_f1_lr   = [n for n, f in f1_lr.items()   if f < 0.20]
    low_f1_rf   = [n for n, f in f1_rf.items()   if f < 0.20]

    lines.append(f"  Cuisines with <20 test samples : {', '.join(low_support) or 'None'}")
    lines.append(f"  Low F1 (<0.20) in LR           : {', '.join(low_f1_lr)   or 'None'}")
    lines.append(f"  Low F1 (<0.20) in RF           : {', '.join(low_f1_rf)   or 'None'}")
    lines.append("")
    lines.append("  KEY FINDING: Accuracy is bounded near the majority-class baseline")
    lines.append("  because restaurant metadata (location, price, rating) is a weak")
    lines.append("  signal for cuisine type.  The top predictors are Longitude/Latitude")
    lines.append("  and Average Cost, which correlate with cuisine only indirectly.")
    lines.append("  Adding restaurant-name NLP features would likely give a large lift.")
    lines.append("=" * 70)

    summary_path = os.path.join(out_dir, "evaluation_summary.txt")
    with open(summary_path, "w") as f:
        f.write("\n".join(lines))
    logger.info("Saved → %s", summary_path)

    print("\n" + "\n".join(lines))


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def main() -> tuple[dict, dict]:
    os.makedirs(REPORTS_DIR, exist_ok=True)
    lr_model, rf_model, split, class_names = load_artifacts()
    X_test = split["X_test"]
    y_test = split["y_test"]

    results_lr = compute_metrics(lr_model, X_test, y_test, class_names, "Logistic_Regression")
    results_rf = compute_metrics(rf_model, X_test, y_test, class_names, "Random_Forest")

    plot_confusion_matrix(
        results_lr["confusion_matrix"], class_names, "Logistic Regression",
        os.path.join(REPORTS_DIR, "confusion_matrix_lr.png"),
    )
    plot_confusion_matrix(
        results_rf["confusion_matrix"], class_names, "Random Forest",
        os.path.join(REPORTS_DIR, "confusion_matrix_rf.png"),
    )
    plot_per_cuisine_f1(
        results_lr["per_class_f1"], class_names, "Logistic Regression",
        os.path.join(REPORTS_DIR, "per_cuisine_f1_lr.png"),
    )
    plot_per_cuisine_f1(
        results_rf["per_class_f1"], class_names, "Random Forest",
        os.path.join(REPORTS_DIR, "per_cuisine_f1_rf.png"),
    )
    plot_feature_importance(
        rf_model, split["X_train"].columns.tolist(),
        os.path.join(REPORTS_DIR, "feature_importance_rf.png"),
    )
    plot_bias_analysis(
        results_lr, results_rf, class_names, y_test,
        os.path.join(REPORTS_DIR, "bias_analysis.png"),
    )
    write_summary_report(results_lr, results_rf, class_names, y_test, REPORTS_DIR)

    logger.info("Evaluation complete. All reports saved to: %s", REPORTS_DIR)
    return results_lr, results_rf


if __name__ == "__main__":
    main()
