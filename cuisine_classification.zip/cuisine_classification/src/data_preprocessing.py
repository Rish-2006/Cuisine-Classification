"""
src/data_preprocessing.py
--------------------------
Modular data-cleaning, feature-engineering and encoding pipeline for the
Cuisine Classification task.

Key design decisions
---------------------
* Target label  : primary_cuisine  (the first cuisine listed in the raw
                  'Cuisines' column).  Multi-label rows exist (~64 %) but
                  a single-label setup is deliberately chosen so that
                  standard multiclass classifiers can be used directly.
* Min-class threshold : cuisines with fewer than MIN_CUISINE_SAMPLES rows
                  are dropped to ensure every class is represented in both
                  the train and test folds after a stratified split.
* Encoding      : binary flags (Yes/No) → int; Rating text → ordinal int;
                  City, Currency → one-hot (top-N + "Other" bucket to
                  avoid dimensionality explosion).
* Outliers      : capped at the 1st / 99th percentile for the three
                  right-skewed numeric columns (Average Cost for two,
                  Votes, Aggregate rating).
"""

from __future__ import annotations

import logging
import os
import warnings
from typing import Optional

import numpy as np
import pandas as pd
from sklearn.preprocessing import LabelEncoder

warnings.filterwarnings("ignore")
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  [%(levelname)s]  %(message)s",
    datefmt="%H:%M:%S",
)
logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Constants / configuration
# ---------------------------------------------------------------------------
RAW_DATA_PATH = os.path.join(os.path.dirname(__file__), "..", "data", "dataset.csv")
PROCESSED_DATA_PATH = os.path.join(
    os.path.dirname(__file__), "..", "data", "processed.csv"
)
LABEL_ENCODER_PATH = os.path.join(
    os.path.dirname(__file__), "..", "models", "label_encoder.pkl"
)

MIN_CUISINE_SAMPLES: int = 20        # cuisines below this are removed
TOP_CITY_CATEGORIES: int = 20        # top N cities kept as OHE columns
TOP_CURRENCY_CATEGORIES: int = 10    # top N currencies kept as OHE cols

RATING_TEXT_ORDER = {
    "Not rated": 0,
    "Poor":      1,
    "Average":   2,
    "Good":      3,
    "Very Good": 4,
    "Excellent": 5,
}

NUMERIC_SKEWED_COLS = ["Average Cost for two", "Votes", "Aggregate rating"]

# Features actually used for modelling (set after encoding; built dynamically)
FEATURE_COLUMNS_CACHE: list[str] = []


# ---------------------------------------------------------------------------
# Helper utilities
# ---------------------------------------------------------------------------

def _cap_outliers(series: pd.Series, lower_pct: float = 1, upper_pct: float = 99) -> pd.Series:
    """Winsorise a numeric series at the given percentile bounds."""
    lo = np.percentile(series.dropna(), lower_pct)
    hi = np.percentile(series.dropna(), upper_pct)
    return series.clip(lower=lo, upper=hi)


def _ohe_top_n(
    df: pd.DataFrame,
    col: str,
    top_n: int,
    prefix: Optional[str] = None,
) -> pd.DataFrame:
    """
    One-hot-encode a high-cardinality categorical column by keeping only the
    top-N most frequent values.  All other values are bucketed into an
    '<prefix>_Other' column.
    """
    prefix = prefix or col.replace(" ", "_").lower()
    top_values = df[col].value_counts().head(top_n).index.tolist()
    df[col] = df[col].where(df[col].isin(top_values), other="Other")
    dummies = pd.get_dummies(df[col], prefix=prefix, dtype=int)
    df = pd.concat([df.drop(columns=[col]), dummies], axis=1)
    return df


# ---------------------------------------------------------------------------
# Main preprocessing pipeline
# ---------------------------------------------------------------------------

class DataPreprocessor:
    """
    End-to-end preprocessing pipeline for the Zomato cuisine dataset.

    Usage
    -----
    >>> preprocessor = DataPreprocessor()
    >>> X, y, feature_cols = preprocessor.fit_transform("data/dataset.csv")
    >>> preprocessor.save_processed("data/processed.csv")
    """

    def __init__(
        self,
        min_cuisine_samples: int = MIN_CUISINE_SAMPLES,
        top_city_categories: int = TOP_CITY_CATEGORIES,
        top_currency_categories: int = TOP_CURRENCY_CATEGORIES,
    ):
        self.min_cuisine_samples = min_cuisine_samples
        self.top_city_categories = top_city_categories
        self.top_currency_categories = top_currency_categories
        self.label_encoder = LabelEncoder()
        self._df_processed: Optional[pd.DataFrame] = None
        self.feature_columns: list[str] = []

    # ------------------------------------------------------------------
    # Step 1 – Load
    # ------------------------------------------------------------------

    def load_raw(self, path: str = RAW_DATA_PATH) -> pd.DataFrame:
        logger.info("Loading raw data from: %s", path)
        df = pd.read_csv(path, encoding="utf-8")
        logger.info("Raw shape: %s", df.shape)
        return df

    # ------------------------------------------------------------------
    # Step 2 – Clean & derive target
    # ------------------------------------------------------------------

    def clean(self, df: pd.DataFrame) -> pd.DataFrame:
        logger.info("Cleaning data …")

        # Drop columns that are identifiers or leak / duplicate information
        drop_cols = [
            "Restaurant ID",
            "Restaurant Name",
            "Address",
            "Locality",
            "Locality Verbose",
            "Rating color",         # purely visual; redundant with Rating text
            "Switch to order menu",  # near-zero variance
        ]
        df = df.drop(columns=[c for c in drop_cols if c in df.columns])

        # --- Target: derive primary_cuisine from 'Cuisines' ---
        df["primary_cuisine"] = (
            df["Cuisines"]
            .dropna()
            .str.split(",")
            .str[0]
            .str.strip()
        )
        df = df.drop(columns=["Cuisines"])

        # Drop rows where primary_cuisine could not be determined
        before = len(df)
        df = df.dropna(subset=["primary_cuisine"])
        logger.info("Dropped %d rows with missing cuisine", before - len(df))

        # Drop rare cuisine classes
        counts = df["primary_cuisine"].value_counts()
        valid_cuisines = counts[counts >= self.min_cuisine_samples].index
        before = len(df)
        df = df[df["primary_cuisine"].isin(valid_cuisines)]
        logger.info(
            "Dropped %d rows; rare cuisines removed. Remaining classes: %d",
            before - len(df),
            df["primary_cuisine"].nunique(),
        )

        return df

    # ------------------------------------------------------------------
    # Step 3 – Handle outliers
    # ------------------------------------------------------------------

    def handle_outliers(self, df: pd.DataFrame) -> pd.DataFrame:
        logger.info("Capping outliers (1st–99th percentile) …")
        for col in NUMERIC_SKEWED_COLS:
            if col in df.columns:
                df[col] = _cap_outliers(df[col])
        return df

    # ------------------------------------------------------------------
    # Step 4 – Encode features
    # ------------------------------------------------------------------

    def encode_features(self, df: pd.DataFrame) -> pd.DataFrame:
        logger.info("Encoding features …")

        # Binary Yes/No columns → 1/0
        binary_cols = ["Has Table booking", "Has Online delivery", "Is delivering now"]
        for col in binary_cols:
            if col in df.columns:
                df[col] = df[col].map({"Yes": 1, "No": 0}).fillna(0).astype(int)

        # Ordinal rating text
        if "Rating text" in df.columns:
            df["Rating text"] = (
                df["Rating text"].map(RATING_TEXT_ORDER).fillna(0).astype(int)
            )

        # High-cardinality categoricals → OHE with top-N bucketing
        if "City" in df.columns:
            df = _ohe_top_n(df, "City", self.top_city_categories, prefix="city")
        if "Currency" in df.columns:
            df = _ohe_top_n(df, "Currency", self.top_currency_categories, prefix="currency")

        # Country Code is already numeric but has ~15 distinct values;
        # treat as categorical via OHE for better tree splitting
        if "Country Code" in df.columns:
            df["Country Code"] = df["Country Code"].astype(str)
            dummies = pd.get_dummies(df["Country Code"], prefix="country", dtype=int)
            df = pd.concat([df.drop(columns=["Country Code"]), dummies], axis=1)

        return df

    # ------------------------------------------------------------------
    # Step 5 – Encode target
    # ------------------------------------------------------------------

    def encode_target(self, df: pd.DataFrame) -> tuple[pd.DataFrame, np.ndarray]:
        logger.info("Label-encoding target …")
        y = self.label_encoder.fit_transform(df["primary_cuisine"])
        df = df.drop(columns=["primary_cuisine"])
        return df, y

    # ------------------------------------------------------------------
    # Orchestrator
    # ------------------------------------------------------------------

    def fit_transform(
        self, path: str = RAW_DATA_PATH
    ) -> tuple[pd.DataFrame, np.ndarray, list[str]]:
        """
        Run the full pipeline and return (X, y, feature_columns).
        """
        df = self.load_raw(path)
        df = self.clean(df)
        df = self.handle_outliers(df)
        df = self.encode_features(df)
        df, y = self.encode_target(df)

        # Ensure all remaining columns are numeric (drop any stragglers)
        non_numeric = df.select_dtypes(exclude="number").columns.tolist()
        if non_numeric:
            logger.warning("Dropping non-numeric columns: %s", non_numeric)
            df = df.drop(columns=non_numeric)

        self.feature_columns = df.columns.tolist()
        global FEATURE_COLUMNS_CACHE
        FEATURE_COLUMNS_CACHE = self.feature_columns

        logger.info(
            "Preprocessing complete. X shape: %s | Classes: %d",
            df.shape,
            len(self.label_encoder.classes_),
        )

        # Attach y back for easy saving
        df_save = df.copy()
        df_save["__target__"] = y
        self._df_processed = df_save

        return df, y, self.feature_columns

    # ------------------------------------------------------------------
    # Persist
    # ------------------------------------------------------------------

    def save_processed(self, path: str = PROCESSED_DATA_PATH) -> None:
        if self._df_processed is None:
            raise RuntimeError("Call fit_transform() before save_processed().")
        os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
        self._df_processed.to_csv(path, index=False)
        logger.info("Processed dataset saved → %s", path)

    def get_class_names(self) -> list[str]:
        return list(self.label_encoder.classes_)


# ---------------------------------------------------------------------------
# Convenience loader (used by train.py / evaluate.py)
# ---------------------------------------------------------------------------

def load_processed(path: str = PROCESSED_DATA_PATH) -> tuple[pd.DataFrame, np.ndarray]:
    """Load a previously saved processed CSV and split into X, y."""
    df = pd.read_csv(path)
    y = df["__target__"].values
    X = df.drop(columns=["__target__"])
    return X, y


# ---------------------------------------------------------------------------
# Quick self-test
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    preprocessor = DataPreprocessor()
    X, y, feature_cols = preprocessor.fit_transform(RAW_DATA_PATH)
    preprocessor.save_processed(PROCESSED_DATA_PATH)
    print("\n--- Feature columns ---")
    for col in feature_cols:
        print(" ", col)
    print(f"\nClass names ({len(preprocessor.get_class_names())}):")
    for name in preprocessor.get_class_names():
        print(" ", name)
