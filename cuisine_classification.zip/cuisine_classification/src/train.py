"""
src/train.py
------------
Load preprocessed data, perform a stratified train/test split, train two
classification models (Logistic Regression baseline + Random Forest ensemble),
and persist the trained artifacts to disk.

Models saved
------------
  models/logistic_regression.pkl
  models/random_forest.pkl
  models/split_indices.pkl   (train/test split for reproducibility)
  models/feature_columns.pkl (ordered feature list for inference)

Run as a script
---------------
  python src/train.py
"""

from __future__ import annotations

import logging
import os
import time
import warnings
from typing import Any

import joblib
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import StratifiedKFold, cross_val_score, train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler

warnings.filterwarnings("ignore")
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  [%(levelname)s]  %(message)s",
    datefmt="%H:%M:%S",
)
logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------
BASE_DIR            = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PROCESSED_DATA_PATH = os.path.join(BASE_DIR, "data", "processed.csv")
MODELS_DIR          = os.path.join(BASE_DIR, "models")

MODEL_LR_PATH       = os.path.join(MODELS_DIR, "logistic_regression.pkl")
MODEL_RF_PATH       = os.path.join(MODELS_DIR, "random_forest.pkl")
SPLIT_PATH          = os.path.join(MODELS_DIR, "split_indices.pkl")
FEATURE_COLS_PATH   = os.path.join(MODELS_DIR, "feature_columns.pkl")

RANDOM_STATE = 42
TEST_SIZE    = 0.20
CV_FOLDS     = 5


# ---------------------------------------------------------------------------
# Data loading
# ---------------------------------------------------------------------------

def load_data(path: str = PROCESSED_DATA_PATH) -> tuple[pd.DataFrame, np.ndarray]:
    logger.info("Loading processed data from: %s", path)
    df = pd.read_csv(path)
    y = df["__target__"].values
    X = df.drop(columns=["__target__"])
    logger.info("Loaded  X: %s  |  y: %s", X.shape, y.shape)
    return X, y


# ---------------------------------------------------------------------------
# Train / test split
# ---------------------------------------------------------------------------

def stratified_split(
    X: pd.DataFrame,
    y: np.ndarray,
    test_size: float = TEST_SIZE,
    random_state: int = RANDOM_STATE,
) -> tuple[pd.DataFrame, pd.DataFrame, np.ndarray, np.ndarray]:
    """Stratified 80/20 train-test split preserving class proportions."""
    X_train, X_test, y_train, y_test = train_test_split(
        X, y,
        test_size=test_size,
        random_state=random_state,
        stratify=y,
    )
    logger.info(
        "Split — Train: %d rows | Test: %d rows | Classes: %d",
        len(X_train), len(X_test), len(np.unique(y)),
    )
    return X_train, X_test, y_train, y_test


# ---------------------------------------------------------------------------
# Model definitions
# ---------------------------------------------------------------------------

def build_logistic_regression() -> Pipeline:
    """
    Logistic Regression wrapped in a StandardScaler pipeline.

    Design choices
    --------------
    * solver='lbfgs'         : memory-efficient, handles multinomial natively
    * multi_class='multinomial': full softmax loss over all classes simultaneously
    * C=1.0                  : moderate L2 regularisation
    * max_iter=3000          : ensures convergence for 57 features × 33 classes
    * No class_weight        : 'balanced' hurts accuracy when the majority
                               class (North Indian, ~33%) dominates the signal;
                               the imbalance is reported honestly in evaluation
    """
    return Pipeline([
        ("scaler", StandardScaler()),
        ("clf", LogisticRegression(
            max_iter=3000,
            C=1.0,
            solver="lbfgs",
            multi_class="multinomial",
            random_state=RANDOM_STATE,
            n_jobs=-1,
        )),
    ])


def build_random_forest() -> RandomForestClassifier:
    """
    Random Forest ensemble classifier.

    Design choices
    --------------
    * n_estimators=500          : large enough for stable OOB estimates
    * class_weight='balanced_subsample': each bootstrap gets per-class
      weights recalculated on that subsample — reduces North Indian
      dominance without the instability of global 'balanced'
    * max_features='sqrt'       : standard for classification
    * min_samples_leaf=1        : full depth; regularisation via ensemble
    * n_jobs=-1                 : use all CPU cores
    """
    return RandomForestClassifier(
        n_estimators=500,
        max_features="sqrt",
        min_samples_leaf=1,
        class_weight="balanced_subsample",
        random_state=RANDOM_STATE,
        n_jobs=-1,
    )


# ---------------------------------------------------------------------------
# Cross-validation helper
# ---------------------------------------------------------------------------

def cross_validate_model(
    model: Any,
    X_train: pd.DataFrame,
    y_train: np.ndarray,
    model_name: str,
    cv: int = CV_FOLDS,
) -> None:
    logger.info("Running %d-fold CV for %s …", cv, model_name)
    skf = StratifiedKFold(n_splits=cv, shuffle=True, random_state=RANDOM_STATE)
    scores = cross_val_score(model, X_train, y_train, cv=skf, scoring="accuracy", n_jobs=-1)
    logger.info(
        "%s  CV Accuracy: %.4f ± %.4f  (min=%.4f, max=%.4f)",
        model_name, scores.mean(), scores.std(), scores.min(), scores.max(),
    )


# ---------------------------------------------------------------------------
# Training orchestrator
# ---------------------------------------------------------------------------

def train_and_save(
    X_train: pd.DataFrame,
    y_train: np.ndarray,
    X_test: pd.DataFrame,
    y_test: np.ndarray,
    feature_columns: list[str],
    run_cv: bool = True,
) -> dict[str, Any]:
    os.makedirs(MODELS_DIR, exist_ok=True)

    # ------------------------------------------------------------------ LR
    logger.info("=" * 55)
    logger.info("Training Logistic Regression …")
    t0 = time.time()
    lr_model = build_logistic_regression()

    if run_cv:
        cross_validate_model(lr_model, X_train, y_train, "LogisticRegression")

    lr_model.fit(X_train, y_train)
    lr_time = time.time() - t0
    logger.info(
        "LR  →  train acc: %.4f | test acc: %.4f | time: %.1fs",
        lr_model.score(X_train, y_train),
        lr_model.score(X_test,  y_test),
        lr_time,
    )
    joblib.dump(lr_model, MODEL_LR_PATH)
    logger.info("Saved → %s", MODEL_LR_PATH)

    # ------------------------------------------------------------------ RF
    logger.info("=" * 55)
    logger.info("Training Random Forest …")
    t0 = time.time()
    rf_model = build_random_forest()

    if run_cv:
        cross_validate_model(rf_model, X_train, y_train, "RandomForest")

    rf_model.fit(X_train, y_train)
    rf_time = time.time() - t0
    logger.info(
        "RF  →  train acc: %.4f | test acc: %.4f | time: %.1fs",
        rf_model.score(X_train, y_train),
        rf_model.score(X_test,  y_test),
        rf_time,
    )
    joblib.dump(rf_model, MODEL_RF_PATH)
    logger.info("Saved → %s", MODEL_RF_PATH)

    # ------------------------------------------------------- Persist split
    split_data = {
        "X_train": X_train, "X_test": X_test,
        "y_train": y_train, "y_test": y_test,
    }
    joblib.dump(split_data,      SPLIT_PATH)
    joblib.dump(feature_columns, FEATURE_COLS_PATH)
    logger.info("Saved split indices & feature list → %s", MODELS_DIR)

    return {"lr": lr_model, "rf": rf_model}


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def main(run_cv: bool = True) -> dict[str, Any]:
    X, y = load_data(PROCESSED_DATA_PATH)
    X_train, X_test, y_train, y_test = stratified_split(X, y)
    feature_columns = X.columns.tolist()
    models = train_and_save(X_train, y_train, X_test, y_test, feature_columns, run_cv=run_cv)
    logger.info("Training pipeline complete.")
    return models


if __name__ == "__main__":
    main(run_cv=True)
